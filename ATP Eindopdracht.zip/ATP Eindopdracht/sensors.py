import ctypes
import time

class BME280:
    def __init__(self):
        self.bme280_lib = ctypes.CDLL("BME280.dll")

    def read_temperature(self):
        return self.bme280_lib.readMockedTemperature()

    def read_humidity(self):
        return self.bme280_lib.readMockedHumidity()

class OPT3002:
    def __init__(self):
        self.opt3002_lib = ctypes.CDLL("OPT3002.dll")

    def read_light_intensity(self):
        return self.opt3002_lib.readMockedLightIntensity()

class Servo:
    def __init__(self):
        self.servo_lib = ctypes.CDLL("Servo.dll")

    def open_ventilation(self):
        self.servo_lib.openVentilation()

    def close_ventilation(self):
        self.servo_lib.closeVentilation()
