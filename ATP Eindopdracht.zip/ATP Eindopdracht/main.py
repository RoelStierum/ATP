import time
from ctypes import CDLL

# Laad de gedeelde bibliotheek in
sensors_lib = CDLL('./sensors.so')

# Definieer de functies die we willen oproepen
read_temperature = sensors_lib.readMockedTemperature
read_light_intensity = sensors_lib.readMockedLightIntensity

# Simuleer het inladen van de C++-klassen, omdat we alleen een simulatie hebben
class BME280:
    def read_temperature(self):
        return read_temperature()

class OPT3002:
    def read_light_intensity(self):
        return read_light_intensity()

class Servo:
    def open_ventilation(self):
        print("Opening ventilation")

    def close_ventilation(self):
        print("Closing ventilation")

class LED:
    def turn_on(self):
        print("Turning LED on")

    def turn_off(self):
        print("Turning LED off")

goal_temperature = 20
goal_light_intensity = 750

sensors = {
    'bme280': BME280(),
    'opt3002': OPT3002(),
    'servo': Servo()
}

status_led = LED()

while True:
    current_temperature = sensors['bme280'].read_temperature()
    current_light_intensity = sensors['opt3002'].read_light_intensity()

    if current_temperature > goal_temperature:
        sensors['servo'].open_ventilation()
    else:
        sensors['servo'].close_ventilation()

    if current_light_intensity < goal_light_intensity:
        status_led.turn_on()
    else:
        status_led.turn_off()

    print("Temp goal: ", goal_temperature, " Current: ", current_temperature)
    print("Light goal: ", goal_light_intensity, " Current: ", current_light_intensity)
    print("----------------------------------------------")

    time.sleep(0.5)
